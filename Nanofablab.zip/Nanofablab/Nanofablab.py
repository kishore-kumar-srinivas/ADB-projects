from flask import Flask, render_template,request
import os
import sqlite3


app = Flask(__name__,template_folder='template')

conn = sqlite3.connect("Nanofablab.db", check_same_thread=False)
k=conn.cursor()

@app.route('/')
def home():
   return render_template('index.html')

@app.route('/inspage',methods=['GET','POST'])
def inspage():
    return render_template('insert.html')

@app.route('/uppage',methods=['GET','POST'])
def uppage():
    return render_template('update.html')


@app.route('/delpage',methods=['GET','POST'])
def delpage():
    return render_template('delete.html')

@app.route('/insert',methods=['GET','POST'])
def insert():
    tname=str(request.form['tname'])
    status=str(request.form['status'])
    service=str(request.form['service'])
    oname=str(request.form['oname'])
    query='INSERT INTO nanofablab (name,WorkStatus,Return_to_Service,Tool_Operator) VALUES ("'+tname+'","'+status+'","'+service+'","'+oname+'");'
    k.execute(query)
    query1='select * from nanofablab'
    k.execute(query1)
    data=k.fetchall()
    conn.commit()
    return render_template('table.html',row=data)


@app.route('/update',methods=['GET','POST'])
def update():
    col=str(request.form['col'])
    update=str(request.form['update'])
    cond=str(request.form['cond'])
    query='UPDATE TABLE nanofablab SET "'+col+'"="'+update+'" WHERE "'+col+'"="'+cond+'"' 
    k.execute(query)
    query1='select * from nanofablab'
    k.execute(query1)
    data=k.fetchall()
    conn.commit()
    return render_template('table.html',row=data)





@app.route('/delete',methods=['GET','POST'])
def delete():
    input=str(request.form['input'])
    id=str(request.form["id"])
    query='DELETE FROM nanofablab WHERE "'+input+'"="'+id+'"'
    k.execute(query)
    query1='select * from nanofablab'
    k.execute(query1)
    data=k.fetchall()
    conn.commit()
    return render_template('table.html',row=data)


@app.route('/table',methods=['GET','POST'])
def table():
    query1='select * from nanofablab'
    k.execute(query1)
    data=k.fetchall()
    conn.commit()

    return render_template('table.html',row=data)

if __name__=='__main__':
    app.debug=True
    app.run()